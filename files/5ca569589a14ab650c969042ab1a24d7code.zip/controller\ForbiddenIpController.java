package com.eports.ad.ms.controller;

import java.util.Arrays;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.baomidou.mybatisplus.plugins.Page;

import com.eports.ad.ms.entity.ForbiddenIp;
import com.eports.ad.ms.service.ForbiddenIpService;


/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@RestController
@RequestMapping("/forbiddenip")
public class ForbiddenIpController {
    @Autowired
    private ForbiddenIpService forbiddenIpService;


    /**
    *  get list
    * @param params
    * @return
    */
    @GetMapping("/page")
    public Page page(@RequestParam Map<String, Object> params) {
      return  forbiddenIpService.selectPage(new Query<>(params), new EntityWrapper<>());
    }


    /**
     * get single info
     * @param id
     * @return R
     */
    @GetMapping("/{id}")
    public R info(@PathVariable("id") String id){
			ForbiddenIp forbiddenIp = forbiddenIpService.selectById(id);
			return new R<>(forbiddenIp);
    }

    /**
     * save
     * @param forbiddenIp
     * @return R
     */
    @PostMapping("/save")
    public R save(@RequestBody ForbiddenIp forbiddenIp){
			forbiddenIpService.insert(forbiddenIp);
			return new R<>(Boolean.TRUE);
    }

    /**
     * update
     * @param forbiddenIp
     * @return R
     */
    @PutMapping("/update")
    public R update(@RequestBody ForbiddenIp forbiddenIp){
			forbiddenIpService.updateById(forbiddenIp);
      return new R<>(Boolean.TRUE);
    }

    /**
     * delete
     * @param ids
     * @return R
     */
    @DeleteMapping("/delete")
    public R delete(@RequestBody String[] ids){
			forbiddenIpService.deleteBatchIds(Arrays.asList(ids));
      return new R<>(Boolean.TRUE);
    }

}
