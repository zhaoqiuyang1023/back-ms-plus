package com.eports.ad.ms.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;


/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("forbidden_mail")
public class ForbiddenMail extends Model<ForbiddenMail> {
private static final long serialVersionUID=1L;


        @TableId(type = IdType.UUID)
    @TableField(value = "id")
@ApiModelProperty(value = "")
private String id;

    @TableField(value = "mail")
@ApiModelProperty(value = "国家")
private String mail;

    @TableField(value = "account_name")
@ApiModelProperty(value = "")
private String accountName;

    @TableField(value = "date_create")
@ApiModelProperty(value = "创建时间")
private Date dateCreate;

    @TableField(value = "email_status")
@ApiModelProperty(value = "ip状态/0是黑名单，1是解除黑名单")
private String emailStatus;

/**
 * primary key
 */
@Override
protected Serializable pkVal(){
        return this.id;
        }
        }
