package com.eports.ad.ms.service.impl;

import org.springframework.stereotype.Service;

import java.util.Map;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import com.eports.ad.ms.mapper.ForbiddenIpMapper;
import com.eports.ad.ms.entity.ForbiddenIp;
import com.eports.ad.ms.service.ForbiddenIpService;

/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@Service("forbiddenIpService")
public class ForbiddenIpServiceImpl extends ServiceImpl<ForbiddenIpMapper, ForbiddenIp> implements ForbiddenIpService {

}
