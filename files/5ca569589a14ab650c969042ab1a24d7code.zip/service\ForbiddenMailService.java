package com.eports.ad.ms.service;

import com.baomidou.mybatisplus.service.IService;
import com.eports.ad.ms.entity.ForbiddenMail;

/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
public interface ForbiddenMailService extends IService<ForbiddenMail> {
}

