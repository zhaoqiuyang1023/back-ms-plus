package com.eports.ad.ms.controller;

import java.util.Arrays;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.baomidou.mybatisplus.plugins.Page;

import com.eports.ad.ms.entity.ForbiddenLogin;
import com.eports.ad.ms.service.ForbiddenLoginService;


/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@RestController
@RequestMapping("/forbiddenlogin")
public class ForbiddenLoginController {
    @Autowired
    private ForbiddenLoginService forbiddenLoginService;


    /**
    *  get list
    * @param params
    * @return
    */
    @GetMapping("/page")
    public Page page(@RequestParam Map<String, Object> params) {
      return  forbiddenLoginService.selectPage(new Query<>(params), new EntityWrapper<>());
    }


    /**
     * get single info
     * @param id
     * @return R
     */
    @GetMapping("/{id}")
    public R info(@PathVariable("id") String id){
			ForbiddenLogin forbiddenLogin = forbiddenLoginService.selectById(id);
			return new R<>(forbiddenLogin);
    }

    /**
     * save
     * @param forbiddenLogin
     * @return R
     */
    @PostMapping("/save")
    public R save(@RequestBody ForbiddenLogin forbiddenLogin){
			forbiddenLoginService.insert(forbiddenLogin);
			return new R<>(Boolean.TRUE);
    }

    /**
     * update
     * @param forbiddenLogin
     * @return R
     */
    @PutMapping("/update")
    public R update(@RequestBody ForbiddenLogin forbiddenLogin){
			forbiddenLoginService.updateById(forbiddenLogin);
      return new R<>(Boolean.TRUE);
    }

    /**
     * delete
     * @param ids
     * @return R
     */
    @DeleteMapping("/delete")
    public R delete(@RequestBody String[] ids){
			forbiddenLoginService.deleteBatchIds(Arrays.asList(ids));
      return new R<>(Boolean.TRUE);
    }

}
