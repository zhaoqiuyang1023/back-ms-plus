package com.eports.ad.ms.mapper;

import com.eports.ad.ms.entity.ForbiddenIp;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@Mapper
public interface ForbiddenIpMapper extends BaseMapper<ForbiddenIp> {

}
