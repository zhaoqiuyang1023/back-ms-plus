package com.eports.ad.ms.entity;

import com.baomidou.mybatisplus.activerecord.Model;
import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import io.swagger.annotations.ApiModelProperty;
import com.baomidou.mybatisplus.enums.IdType;

import java.io.Serializable;
import java.util.Date;


/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@Data
@EqualsAndHashCode(callSuper = true)
@TableName("forbidden_ip")
public class ForbiddenIp extends Model<ForbiddenIp> {
private static final long serialVersionUID=1L;


        @TableId(type = IdType.UUID)
    @TableField(value = "id")
@ApiModelProperty(value = "")
private String id;

    @TableField(value = "country")
@ApiModelProperty(value = "国家")
private String country;

    @TableField(value = "date_create")
@ApiModelProperty(value = "创建时间")
private Date dateCreate;

    @TableField(value = "date_update")
@ApiModelProperty(value = "修改时间")
private Date dateUpdate;

    @TableField(value = "ip_status")
@ApiModelProperty(value = "ip状态/0是黑名单，1是解除黑名单")
private String ipStatus;

/**
 * primary key
 */
@Override
protected Serializable pkVal(){
        return this.id;
        }
        }
