package com.eports.ad.ms.service;

import com.baomidou.mybatisplus.service.IService;
import com.eports.ad.ms.entity.ForbiddenLogin;

/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
public interface ForbiddenLoginService extends IService<ForbiddenLogin> {
}

