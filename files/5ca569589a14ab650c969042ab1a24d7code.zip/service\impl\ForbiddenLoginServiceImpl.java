package com.eports.ad.ms.service.impl;

import org.springframework.stereotype.Service;

import java.util.Map;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import com.eports.ad.ms.mapper.ForbiddenLoginMapper;
import com.eports.ad.ms.entity.ForbiddenLogin;
import com.eports.ad.ms.service.ForbiddenLoginService;

/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@Service("forbiddenLoginService")
public class ForbiddenLoginServiceImpl extends ServiceImpl<ForbiddenLoginMapper, ForbiddenLogin> implements ForbiddenLoginService {

}
