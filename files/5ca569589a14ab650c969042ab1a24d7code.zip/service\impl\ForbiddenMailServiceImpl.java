package com.eports.ad.ms.service.impl;

import org.springframework.stereotype.Service;

import java.util.Map;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;

import com.eports.ad.ms.mapper.ForbiddenMailMapper;
import com.eports.ad.ms.entity.ForbiddenMail;
import com.eports.ad.ms.service.ForbiddenMailService;

/**
 * 
 *
 * @author Alan
 * @date 2019-07-17 10:57:43
 */
@Service("forbiddenMailService")
public class ForbiddenMailServiceImpl extends ServiceImpl<ForbiddenMailMapper, ForbiddenMail> implements ForbiddenMailService {

}
